package com.neko.ai

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.graphics.Bitmap
import android.os.Build
import android.os.Bundle
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import androidx.core.content.ContextCompat
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.coroutines.suspendCoroutine

/** Reads on-screen text only when the bubble is tapped (snapshot), takes screenshots on request, and can write a rewrite back into the focused field. */
class NekoAccessibilityService : AccessibilityService() {
    override fun onServiceConnected() { instance = this }
    private val imePackages by lazy {
        (getSystemService(INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager)
            .enabledInputMethodList.map { it.packageName }.toSet()
    }

    /** Tracks which app is in front so the bubble can hide itself in apps you didn't enable. */
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg == packageName || pkg == "com.android.systemui" || pkg in imePackages) return
        if (pkg != foreground) { foreground = pkg; onForeground?.invoke(pkg) }
    }
    override fun onInterrupt() {}
    override fun onUnbind(intent: Intent?): Boolean { instance = null; draftNode = null; return super.onUnbind(intent) }

    companion object {
        var instance: NekoAccessibilityService? = null
        var foreground: String? = null
        var onForeground: ((String) -> Unit)? = null
        var screen: String? = null
        var draft: String? = null
        private var draftNode: AccessibilityNodeInfo? = null   // the text field that was focused at snapshot time

        /** Call right when the bubble is tapped, while the other app is still in front. */
        private val cardRe = Regex("\\b(?:\\d[ -]?){13,19}\\b")
        private val phoneRe = Regex("\\+?\\d[\\d\\s().-]{7,}\\d")
        private val mailRe = Regex("[\\w.+-]+@[\\w-]+\\.[\\w.-]+")

        /** Hide emails, phone numbers and card numbers before text leaves the phone. */
        private fun mask(t: String) = t.replace(cardRe, "[card]").replace(phoneRe, "[phone]").replace(mailRe, "[email]")

        fun snapshot() {
            val svc = instance ?: return
            val root = svc.rootInActiveWindow ?: return
            val p = svc.getSharedPreferences("neko", android.content.Context.MODE_PRIVATE)
            val sb = StringBuilder(); var d: String? = null; var dn: AccessibilityNodeInfo? = null
            fun walk(n: AccessibilityNodeInfo?) {
                if (n == null || sb.length > 6000 || n.isPassword) return   // never read password fields
                n.text?.let {
                    sb.append(if (n.isShowingHintText) "" else it).append('\n')
                    if (n.isEditable && n.isFocused) { d = if (n.isShowingHintText) "" else it.toString(); dn = n }
                }
                // an empty focused text box still counts, so Smart reply can fill it
                if (n.isEditable && n.isFocused && dn == null) { d = ""; dn = n }
                for (i in 0 until n.childCount) walk(n.getChild(i))
            }
            walk(root)
            screen = if (!p.flag("p_screen")) null else sb.toString().let { if (p.flag("p_mask")) mask(it) else it }
            draft = d; draftNode = dn
        }

        fun setDraft(text: String): Boolean {
            val s = instance ?: return false
            val args = Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text) }
            // 1) the field we saw when the bubble was tapped (still valid after the chat window takes focus)
            draftNode?.let { if (it.refresh() && it.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) return true }
            // 2) fall back to whichever field has input focus in another app
            val roots = s.windows.mapNotNull { it.root }.filter { it.packageName != s.packageName } + listOfNotNull(s.rootInActiveWindow)
            for (r in roots) {
                val n = r.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: continue
                return n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
            }
            return false
        }

        /** Screenshot of the whole display (Android 11+). Hide Neko's own windows before calling. */
        suspend fun capture(): Bitmap {
            val s = instance ?: throw IllegalStateException("Turn on Neko in Accessibility settings first.")
            if (Build.VERSION.SDK_INT < 30) throw IllegalStateException("Screen capture needs Android 11 or newer.")
            return suspendCoroutine { cont ->
                s.takeScreenshot(Display.DEFAULT_DISPLAY, ContextCompat.getMainExecutor(s), object : TakeScreenshotCallback {
                    override fun onSuccess(r: ScreenshotResult) {
                        val hw = Bitmap.wrapHardwareBuffer(r.hardwareBuffer, r.colorSpace)
                        val soft = hw?.copy(Bitmap.Config.ARGB_8888, false)
                        r.hardwareBuffer.close()
                        if (soft != null) cont.resume(soft)
                        else cont.resumeWithException(IllegalStateException("Couldn't read the screenshot."))
                    }
                    override fun onFailure(code: Int) {
                        cont.resumeWithException(IllegalStateException(
                            if (code == ERROR_TAKE_SCREENSHOT_SECURE_WINDOW) "This screen blocks screenshots."
                            else if (code == ERROR_TAKE_SCREENSHOT_INTERVAL_TIME_SHORT) "Too fast! Wait a second and try again."
                            else "Screenshot failed ($code)."
                        ))
                    }
                })
            }
        }
    }
}

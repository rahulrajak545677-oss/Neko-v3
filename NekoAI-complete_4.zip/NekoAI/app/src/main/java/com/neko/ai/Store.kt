package com.neko.ai

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Build
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.time.LocalDate
import java.time.ZoneId

/** Lets receivers nudge the cat bubble (wiggle + "!") when a reminder or check-in arrives. */
object BubbleBus { @Volatile var alert: (() -> Unit)? = null }

// ---------------------------------------------------------------- Remember me

/** Facts Neko remembers about you, one per line, stored only on this phone. */
object Mem {
    const val MAX = 30
    fun parse(raw: String): List<String> = raw.split("\n").map { it.trim() }.filter { it.isNotEmpty() }
    fun add(raw: String, fact: String): String {
        val f = fact.replace("\n", " ").trim().take(140)
        if (f.isEmpty()) return raw
        return (parse(raw).filter { !it.equals(f, true) } + f).takeLast(MAX).joinToString("\n")
    }
    fun remove(raw: String, fact: String) = parse(raw).filter { it != fact }.joinToString("\n")
    private val nameRe = Regex("(?i)(?:name is|called|call me|i am|i'm)\\s+([\\p{L}]{2,20})")
    fun name(facts: List<String>): String? = facts.firstNotNullOfOrNull { nameRe.find(it)?.groupValues?.get(1) }
}

// ---------------------------------------------------------------- Chat history

data class SavedMsg(val mine: Boolean, val text: String)
data class SavedChat(val id: String, val title: String, val updated: Long, val pinned: Boolean, val msgs: List<SavedMsg>)

/** Saved conversations in a small JSON file inside the app's private storage. */
class HistoryStore(ctx: Context) {
    private val file = File(ctx.filesDir, "chats.json")

    @Synchronized private fun read(): List<SavedChat> = try {
        val arr = JSONObject(file.readText()).getJSONArray("chats")
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i); val m = o.getJSONArray("msgs")
            SavedChat(
                o.getString("id"), o.getString("title"), o.getLong("updated"), o.optBoolean("pinned"),
                (0 until m.length()).map { j -> m.getJSONObject(j).let { SavedMsg(it.getBoolean("m"), it.getString("t")) } }
            )
        }
    } catch (e: Exception) { emptyList() }

    @Synchronized private fun write(list: List<SavedChat>) {
        val arr = JSONArray()
        list.forEach { c ->
            arr.put(JSONObject().put("id", c.id).put("title", c.title).put("updated", c.updated).put("pinned", c.pinned)
                .put("msgs", JSONArray().also { a -> c.msgs.forEach { a.put(JSONObject().put("m", it.mine).put("t", it.text)) } }))
        }
        file.writeText(JSONObject().put("chats", arr).toString())
    }

    fun all(): List<SavedChat> = read().sortedWith(compareByDescending<SavedChat> { it.pinned }.thenByDescending { it.updated })
    fun get(id: String): SavedChat? = read().firstOrNull { it.id == id }

    @Synchronized fun save(c: SavedChat) {
        val list = read().filter { it.id != c.id } + c
        // keep the newest 100; pinned chats are never dropped
        val keep = list.filter { it.pinned } + list.filter { !it.pinned }.sortedByDescending { it.updated }.take(100)
        write(keep)
    }
    @Synchronized fun delete(id: String) = write(read().filter { it.id != id })
    @Synchronized fun setPinned(id: String, pinned: Boolean) = write(read().map { if (it.id == id) it.copy(pinned = pinned) else it })
    @Synchronized fun clear() = write(emptyList())
}

// ---------------------------------------------------------------- Reminders

data class Reminder(val id: Int, val at: Long, val text: String)

object Reminders {
    private fun file(ctx: Context) = File(ctx.filesDir, "reminders.json")

    @Synchronized fun all(ctx: Context): List<Reminder> = try {
        val arr = JSONArray(file(ctx).readText())
        (0 until arr.length()).map { arr.getJSONObject(it).let { o -> Reminder(o.getInt("id"), o.getLong("at"), o.getString("text")) } }
            .sortedBy { it.at }
    } catch (e: Exception) { emptyList() }

    @Synchronized private fun write(ctx: Context, list: List<Reminder>) {
        file(ctx).writeText(JSONArray().also { a -> list.forEach { a.put(JSONObject().put("id", it.id).put("at", it.at).put("text", it.text)) } }.toString())
    }

    private fun pending(ctx: Context, r: Reminder): PendingIntent = PendingIntent.getBroadcast(
        ctx, r.id, Intent(ctx, ReminderReceiver::class.java).putExtra("id", r.id).putExtra("text", r.text),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    /** setAlarmClock fires on time without the special "exact alarm" permission. */
    private fun schedule(ctx: Context, r: Reminder) {
        val am = ctx.getSystemService(AlarmManager::class.java)
        val show = PendingIntent.getActivity(ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        am.setAlarmClock(AlarmManager.AlarmClockInfo(r.at, show), pending(ctx, r))
    }

    fun add(ctx: Context, at: Long, text: String): Reminder {
        val r = Reminder((System.currentTimeMillis() % Int.MAX_VALUE).toInt(), at, text.trim().take(120).ifEmpty { "Reminder" })
        write(ctx, all(ctx) + r)
        schedule(ctx, r)
        return r
    }

    fun remove(ctx: Context, id: Int) {
        all(ctx).firstOrNull { it.id == id }?.let { ctx.getSystemService(AlarmManager::class.java).cancel(pending(ctx, it)) }
        write(ctx, all(ctx).filter { it.id != id })
    }

    fun rescheduleAll(ctx: Context) {
        val now = System.currentTimeMillis()
        all(ctx).filter { it.at > now }.forEach { schedule(ctx, it) }
    }

    fun channel(ctx: Context) {
        ctx.getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("neko_remind", "Neko reminders", NotificationManager.IMPORTANCE_HIGH))
    }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val text = intent.getStringExtra("text").orEmpty().ifEmpty { "Reminder" }
        Reminders.channel(ctx)
        val open = PendingIntent.getActivity(ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = android.app.Notification.Builder(ctx, "neko_remind")
            .setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("Neko reminder ⏰")
            .setContentText(text).setStyle(android.app.Notification.BigTextStyle().bigText(text))
            .setContentIntent(open).setAutoCancel(true).build()
        try { ctx.getSystemService(NotificationManager::class.java).notify(intent.getIntExtra("id", 1) + 1000, n) } catch (_: SecurityException) {}
        Reminders.remove(ctx, intent.getIntExtra("id", -1))
        BubbleBus.alert?.invoke()
    }
}

// ---------------------------------------------------------------- Daily check-in

object CheckIn {
    private val lines = listOf(
        "How was your day so far? ☀️", "Anything fun happen today? 😊", "Take a breath. How are you feeling? 💜",
        "Did you eat something yet? 🍜", "Tell me one good thing from today! ✨", "Hi! Just checking in. What are you up to?"
    )

    fun message(prefs: SharedPreferences): String {
        val name = Mem.name(Mem.parse(prefs.getString("mem", "").orEmpty()))
        val line = lines[(LocalDate.now().toEpochDay() % lines.size).toInt()]
        return if (name != null) "Hey $name! $line" else "Hey! $line"
    }

    private fun pending(ctx: Context) = PendingIntent.getBroadcast(
        ctx, 4242, Intent(ctx, CheckInReceiver::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    /** (Re)schedules the next check-in, or cancels it when the feature is off. */
    fun schedule(ctx: Context, prefs: SharedPreferences) {
        val am = ctx.getSystemService(AlarmManager::class.java)
        am.cancel(pending(ctx))
        if (!prefs.flag("ci_on")) return
        val zone = ZoneId.systemDefault()
        var t = LocalDate.now().atTime(prefs.getInt("ciHour", 20), prefs.getInt("ciMin", 0)).atZone(zone)
        if (t.toInstant().toEpochMilli() <= System.currentTimeMillis() + 60_000) t = t.plusDays(1)
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t.toInstant().toEpochMilli(), pending(ctx))
    }

    /** Posts the check-in notification. Tapping it opens the friend chat if Neko is on, otherwise the app. */
    fun post(ctx: Context, prefs: SharedPreferences) {
        val text = message(prefs)
        ctx.getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("neko_checkin", "Neko check-in", NotificationManager.IMPORTANCE_DEFAULT))
        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        val tap = if (prefs.getBoolean("on", false))
            PendingIntent.getForegroundService(ctx, 7, Intent(ctx, BubbleService::class.java).setAction(BubbleService.ACTION_CHECKIN).putExtra("text", text), flags)
        else PendingIntent.getActivity(ctx, 7, Intent(ctx, MainActivity::class.java), flags)
        val n = android.app.Notification.Builder(ctx, "neko_checkin")
            .setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("Neko 😼").setContentText(text)
            .setContentIntent(tap).setAutoCancel(true).build()
        try { ctx.getSystemService(NotificationManager::class.java).notify(7, n) } catch (_: SecurityException) {}
        BubbleBus.alert?.invoke()
    }
}

class CheckInReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val prefs = ctx.getSharedPreferences("neko", Context.MODE_PRIVATE)
        if (prefs.flag("ci_on")) { CheckIn.post(ctx, prefs); CheckIn.schedule(ctx, prefs) }
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        Reminders.rescheduleAll(ctx)
        CheckIn.schedule(ctx, ctx.getSharedPreferences("neko", Context.MODE_PRIVATE))
    }
}

package com.neko.ai

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/** TinyFish web APIs: Search (ranked results), Fetch (page to markdown), Agent (goal-based browser task). */
object TinyFishClient {
    private fun http(url: String, key: String, post: String?): String {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.setRequestProperty("X-API-Key", key)
            c.connectTimeout = 15000; c.readTimeout = 90000
            if (post != null) {
                c.requestMethod = "POST"; c.doOutput = true
                c.setRequestProperty("Content-Type", "application/json")
                c.outputStream.use { it.write(post.toByteArray()) }
            }
            val code = c.responseCode
            val raw = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.readText().orEmpty()
            if (code !in 200..299) throw NekoException(
                when (code) {
                    401, 403 -> "TinyFish rejected the key or request."
                    402 -> "This TinyFish API needs access or credits on your account."
                    429 -> "TinyFish rate limit reached. Try again shortly."
                    else -> "TinyFish error $code."
                }
            )
            return raw
        } finally { c.disconnect() }
    }

    /** Top 5 results as "title — snippet (url)" lines. */
    suspend fun search(key: String, query: String): String = withContext(Dispatchers.IO) {
        val raw = http("https://api.search.tinyfish.ai?query=${URLEncoder.encode(query, "UTF-8")}", key, null)
        val arr = JSONObject(raw).optJSONArray("results") ?: return@withContext ""
        (0 until minOf(arr.length(), 5)).joinToString("\n") {
            val r = arr.getJSONObject(it)
            "${r.optString("title")} — ${r.optString("snippet")} (${r.optString("url")})"
        }
    }

    /** Page text from Fetch (results[0].text), trimmed. */
    suspend fun fetch(key: String, url: String): String = withContext(Dispatchers.IO) {
        val body = JSONObject().put("urls", JSONArray().put(url)).put("format", "markdown").toString()
        val raw = http("https://api.fetch.tinyfish.ai", key, body)
        val first = JSONObject(raw).optJSONArray("results")?.optJSONObject(0)
        (first?.optString("text")?.ifBlank { null } ?: raw).take(8000)
    }

    /** Runs a natural-language task on a real website and waits for the result. */
    suspend fun agent(key: String, url: String, goal: String): String = withContext(Dispatchers.IO) {
        val body = JSONObject().put("url", url).put("goal", goal).toString()
        http("https://agent.tinyfish.ai/v1/automation/run", key, body).take(6000)
    }
}

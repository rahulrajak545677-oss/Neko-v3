package com.neko.ai

import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private val Gold1 = Color(0xFFF5D77A)
private val Gold2 = Color(0xFFE0A93B)

/** The cat from the mockup, hue-shifted to the chosen neon skin, optionally wearing an unlocked look. Asleep = greyed out. */
@Composable
fun CatFace(on: Boolean, hue: Float, modifier: Modifier = Modifier, accessory: Int = 0) {
    Box(modifier) {
        Image(
            painterResource(R.drawable.neko_cat), "Neko", Modifier.fillMaxSize(), contentScale = ContentScale.Fit,
            alpha = if (on) 1f else 0.55f,
            colorFilter = ColorFilter.colorMatrix(
                if (on) ColorMatrix(Cfg.hueMatrix(hue)) else ColorMatrix().apply { setToSaturation(0f) }
            )
        )
        if (accessory > 0 && on) Canvas(Modifier.fillMaxSize()) {
            val sc = minOf(size.width / 640f, size.height / 559f)
            val w = 640f * sc; val h = 559f * sc
            drawIntoCanvas { Growth.drawAccessory(it.nativeCanvas, (size.width - w) / 2f, (size.height - h) / 2f, w, h, accessory) }
        }
    }
}

/** Rotating rings, twinkling pixels and the cat. Tap: the face flips 360 degrees, then onTap fires mid-flip. */
@Composable
fun NekoOrb(on: Boolean, skin: Skin, mood: Int, grow: Float, accessory: Int, onTap: () -> Unit) {
    val accent = skin.edge
    val t = rememberInfiniteTransition(label = "orb")
    val spin by t.animateFloat(0f, 360f, infiniteRepeatable(tween(5000, easing = LinearEasing)), label = "spin")
    val back by t.animateFloat(0f, -360f, infiniteRepeatable(tween(16000, easing = LinearEasing)), label = "back")
    val bobMs = when (mood) { 1 -> 3200; 2 -> 1100; else -> 2000 }   // sleepy floats slowly, excited bounces
    val bob by t.animateFloat(0f, 1f, infiniteRepeatable(tween(bobMs, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "bob")
    val tw by t.animateFloat(0f, 1f, infiniteRepeatable(tween(2600), RepeatMode.Reverse), label = "tw")
    val ringAlpha by animateFloatAsState(if (on) 1f else 0.28f, label = "ring")
    val flip = remember { Animatable(0f) }
    val scope = rememberCoroutineScope()

    Box(
        Modifier.size(260.dp).clickable(remember { MutableInteractionSource() }, null) {
            scope.launch {
                launch { flip.animateTo(360f, tween(900)); flip.snapTo(0f) }
                delay(450); onTap()
            }
        },
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.fillMaxSize().alpha(ringAlpha)) {
            val sw = 4.dp.toPx()
            drawCircle(Brush.radialGradient(listOf(accent.copy(alpha = .35f), Color.Transparent)), size.minDimension / 2.2f)
            rotate(spin) {
                drawArc(
                    Brush.sweepGradient(listOf(Color.Transparent, accent, Magenta, Color.Transparent)),
                    0f, 360f, false, topLeft = Offset(sw / 2, sw / 2),
                    size = Size(size.width - sw, size.height - sw), style = Stroke(sw)
                )
            }
            rotate(back) {
                drawCircle(
                    accent.copy(alpha = .65f), size.minDimension / 2 - 24.dp.toPx(),
                    style = Stroke(2.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(12f, 12f)))
                )
            }
            rotate(spin * 1.6f) {
                drawRect(Cyan, Offset(center.x - 4.5.dp.toPx(), 5.dp.toPx()), Size(9.dp.toPx(), 9.dp.toPx()))
            }
            listOf(Offset(.93f, .2f), Offset(.04f, .32f), Offset(.88f, .84f), Offset(.1f, .88f), Offset(.52f, .0f)).forEachIndexed { i, p ->
                val sz = (if (i % 2 == 0) 8 else 5).dp.toPx()
                drawRect(accent.copy(alpha = .25f + .6f * (if (i % 2 == 0) tw else 1f - tw)), Offset(p.x * size.width, p.y * size.height), Size(sz, sz))
            }
        }
        CatFace(
            on, skin.hue,
            Modifier.width((170 * grow).dp).height((146 * grow).dp).graphicsLayer {
                rotationY = flip.value
                cameraDistance = 12f * density
                translationY = -8.dp.toPx() * bob
            },
            accessory = accessory
        )
    }
}

@Composable
fun PermChip(name: String, ok: Boolean, accent: Color, modifier: Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(14.dp)
    Row(
        modifier.clip(shape).border(1.dp, if (ok) accent else Color(0x1CFFFFFF), shape)
            .background(Color(0x0DFFFFFF)).clickable(onClick = onClick).padding(vertical = 10.dp),
        horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(8.dp).background(if (ok) Color(0xFF4ADE80) else Color(0x33FFFFFF), CircleShape))
        Spacer(Modifier.width(6.dp))
        Text(name, color = Color.White, fontSize = 12.sp)
    }
}

@Composable
private fun GlassTile(
    modifier: Modifier, icon: ImageVector, title: String, sub: String, accent: Color, strong: Boolean = false, onClick: () -> Unit
) {
    val shape = RoundedCornerShape(20.dp)
    Column(
        modifier.clip(shape)
            .border(1.dp, Brush.linearGradient(listOf(accent.copy(alpha = .7f), Color(0x22FFFFFF))), shape)
            .background(if (strong) accent.copy(alpha = .22f) else Color(0x0DFFFFFF))
            .clickable(onClick = onClick).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Icon(icon, null, tint = accent, modifier = Modifier.size(22.dp))
        Spacer(Modifier.height(2.dp))
        Text(title, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
        Text(sub, color = Muted, fontSize = 12.sp)
    }
}

@Composable
fun NekoHome(
    s: NekoSettings, on: Boolean, perms: List<Boolean>,
    onPower: () -> Unit, onPerm: (Int) -> Unit, onGrantAll: () -> Unit, onOpen: (String) -> Unit
) {
    val skin = s.currentSkin
    val accent = skin.edge
    val names = listOf("Overlay", "Reader", "Capture", "Mic")
    Column(
        Modifier.fillMaxSize().drawBehind {
            drawRect(Void)
            val c = Offset(size.width / 2f, 0f)
            drawCircle(Brush.radialGradient(listOf(accent.copy(alpha = .32f), Color.Transparent), c, size.width * .9f), size.width * .9f, c)
        }.statusBarsPadding().verticalScroll(rememberScrollState()).padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Neko AI", style = TextStyle(brush = Brush.horizontalGradient(listOf(Color.White, Magenta)), fontSize = 22.sp, fontWeight = FontWeight.Bold))
                Spacer(Modifier.width(6.dp))
                Icon(Icons.Rounded.Verified, "Verified", tint = accent, modifier = Modifier.size(18.dp))
            }
            Box(Modifier.clip(CircleShape).background(Brush.horizontalGradient(listOf(Gold1, Gold2))).padding(horizontal = 12.dp, vertical = 4.dp)) {
                Text("PREMIUM", color = Color(0xFF2A1A00), fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
            }
        }
        Spacer(Modifier.height(16.dp))
        NekoOrb(on, skin, s.mood, s.growScale, s.accessory, onPower)
        Text(if (on) "Neko is online" else "Neko is asleep", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Text(if (on) "Tap the cat to switch off" else "Tap the cat to wake Neko", color = Muted, fontSize = 13.sp)
        if (s.flag("f_growth")) Text("Lv ${s.level} · ${Growth.title(s.level)}", color = accent, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(22.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            names.forEachIndexed { i, n -> PermChip(n, perms[i], accent, Modifier.weight(1f)) { onPerm(i) } }
        }
        if (perms.any { !it }) {
            Spacer(Modifier.height(12.dp))
            Box(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Brush.horizontalGradient(listOf(accent, Magenta)))
                    .clickable(onClick = onGrantAll).padding(vertical = 14.dp),
                contentAlignment = Alignment.Center
            ) { Text("Grant all permissions", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold) }
        }
        Spacer(Modifier.height(14.dp))
        GlassTile(Modifier.fillMaxWidth(), Icons.Rounded.ChatBubbleOutline, "Try Neko",
            if (on) "Chat with the cat live" else "Preview the chat window", accent, strong = true) { onOpen("try") }
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth().height(IntrinsicSize.Max), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            GlassTile(Modifier.weight(1f).fillMaxHeight(), Icons.Rounded.SentimentSatisfiedAlt, "Bubble look",
                "${s.size} dp · ${Cfg.corners[s.corner.coerceIn(0, 3)].lowercase()}", accent) { onOpen("bubble") }
            GlassTile(Modifier.weight(1f).fillMaxHeight(), Icons.Rounded.AutoAwesome, "AI brain",
                "${s.tone} · ${s.lang}", accent) { onOpen("brain") }
        }
        Spacer(Modifier.height(10.dp))
        GlassTile(Modifier.fillMaxWidth(), Icons.Rounded.Bolt, "Smart features",
            "${s.featuresOn} of ${Cfg.features.size} on", accent, strong = true) { onOpen("smart") }
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth().height(IntrinsicSize.Max), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            GlassTile(Modifier.weight(1f).fillMaxHeight(), Icons.Rounded.GridView, "App control",
                if (s.only) "${s.apps.size} apps enabled" else "All apps", accent) { onOpen("apps") }
            GlassTile(Modifier.weight(1f).fillMaxHeight(), Icons.Rounded.Shield, "Privacy",
                "Reads only on tap", accent) { onOpen("privacy") }
        }
        Spacer(Modifier.height(10.dp))
        GlassTile(Modifier.fillMaxWidth(), Icons.Rounded.Pets, "Cat growth",
            if (s.flag("f_growth")) "Lv ${s.level} · ${Growth.title(s.level)}" else "Off", accent, strong = true) { onOpen("growth") }
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth().height(IntrinsicSize.Max), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            GlassTile(Modifier.weight(1f).fillMaxHeight(), Icons.Rounded.History, "Chat history", "Saved chats", accent) { onOpen("history") }
            GlassTile(Modifier.weight(1f).fillMaxHeight(), Icons.Rounded.Psychology, "Remember me",
                "${Mem.parse(s.memRaw).size} things", accent) { onOpen("memory") }
        }
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth().height(IntrinsicSize.Max), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            GlassTile(Modifier.weight(1f).fillMaxHeight(), Icons.Rounded.NotificationsActive, "Daily check-in",
                if (s.flag("ci_on")) "Daily at ${clock(s.ciHour, s.ciMin)}" else "Off", accent) { onOpen("checkin") }
            GlassTile(Modifier.weight(1f).fillMaxHeight(), Icons.Rounded.Alarm, "Reminders", "Ping me later", accent) { onOpen("remind") }
        }
        Spacer(Modifier.height(24.dp))
        Spacer(Modifier.navigationBarsPadding())
    }
}

fun clock(h: Int, m: Int) = String.format("%d:%02d %s", ((h + 11) % 12) + 1, m, if (h < 12) "AM" else "PM")

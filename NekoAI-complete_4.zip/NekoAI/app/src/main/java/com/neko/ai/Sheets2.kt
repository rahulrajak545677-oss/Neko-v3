package com.neko.ai

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.PushPin
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.time.LocalDate
import java.time.ZoneId
import java.util.Date
import java.util.Locale

// ---------- Chat history ----------

@Composable
fun HistorySheet(s: NekoSettings, onContinue: (String) -> Unit, onDone: () -> Unit) {
    val ctx = LocalContext.current
    val accent = s.currentSkin.edge
    val store = remember { HistoryStore(ctx) }
    var chats by remember { mutableStateOf(store.all()) }
    var query by remember { mutableStateOf("") }
    var open by remember { mutableStateOf<SavedChat?>(null) }
    val fmt = remember { SimpleDateFormat("d MMM, h:mm a", Locale.getDefault()) }
    fun refresh() { chats = store.all() }

    NekoSheet("Chat history", onDone, scroll = false) {
        val o = open
        if (o == null) {
            Panel { ToggleRow("Save chats", "Keep conversations on this phone to read later", s.flag("f_history"), accent) { s.setFlag("f_history", it) } }
            OutlinedTextField(query, { query = it }, label = { Text("Search chats") }, singleLine = true, colors = fieldColors(accent), modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            val shown = chats.filter { query.isBlank() || it.title.contains(query, true) || it.msgs.any { m -> m.text.contains(query, true) } }
            if (shown.isEmpty()) {
                Text(if (chats.isEmpty()) "No saved chats yet. Talk to Neko and they will show up here." else "No chats match.", color = Muted, fontSize = 13.sp)
            } else LazyColumn(Modifier.fillMaxWidth().height(360.dp)) {
                items(shown, key = { it.id }) { c ->
                    Row(Modifier.fillMaxWidth().clickable { open = c }.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(c.title, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text("${fmt.format(Date(c.updated))} · ${c.msgs.size} messages", color = Muted, fontSize = 12.sp)
                        }
                        Icon(Icons.Rounded.PushPin, "Pin", tint = if (c.pinned) accent else Muted,
                            modifier = Modifier.clip(CircleShape).clickable { store.setPinned(c.id, !c.pinned); refresh() }.padding(8.dp))
                        Icon(Icons.Rounded.Delete, "Delete", tint = Muted,
                            modifier = Modifier.clip(CircleShape).clickable { store.delete(c.id); refresh() }.padding(8.dp))
                    }
                }
            }
            if (chats.isNotEmpty()) TextButton(onClick = { store.clear(); refresh() }) { Text("Delete all history", color = accent) }
        } else {
            Text("← All chats", color = accent, fontSize = 13.sp, modifier = Modifier.clickable { open = null }.padding(vertical = 4.dp))
            Text(o.title, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(8.dp))
            LazyColumn(Modifier.fillMaxWidth().height(300.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(o.msgs) { m ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (m.mine) Arrangement.End else Arrangement.Start) {
                        Box(
                            Modifier.widthIn(max = 280.dp).clip(RoundedCornerShape(18.dp))
                                .background(if (m.mine) s.currentSkin.bubble else BotBubble).padding(horizontal = 14.dp, vertical = 8.dp)
                        ) { Text(m.text, color = Color.White, fontSize = 14.sp) }
                    }
                }
            }
            Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Button(
                    onClick = { onContinue(o.id) },
                    colors = ButtonDefaults.buttonColors(containerColor = accent, contentColor = Ink)
                ) { Text("Continue chat") }
                Spacer(Modifier.width(8.dp))
                TextButton(onClick = { store.delete(o.id); open = null; refresh() }) { Text("Delete", color = Muted) }
            }
        }
    }
}

// ---------- Remember me ----------

@Composable
fun MemorySheet(s: NekoSettings, onDone: () -> Unit) {
    val accent = s.currentSkin.edge
    var newFact by remember { mutableStateOf("") }
    LaunchedEffect(Unit) { s.memRaw = s.prefs.getString("mem", "").orEmpty() }   // the chat may have added facts while the app was away
    val facts = Mem.parse(s.memRaw)
    NekoSheet("Remember me", onDone) {
        Panel {
            ToggleRow("Remember me", "Neko uses these facts to chat like a friend who knows you", s.flag("f_memory"), accent) { s.setFlag("f_memory", it) }
            ToggleRow("Auto-learn", "Neko notices lasting facts as you chat. Never health, money or passwords.", s.flag("m_auto"), accent) { s.setFlag("m_auto", it) }
        }
        Panel("Add something") {
            OutlinedTextField(newFact, { newFact = it }, label = { Text("For example: My name is Rahul") }, singleLine = true,
                colors = fieldColors(accent), modifier = Modifier.fillMaxWidth())
            TextButton(onClick = { if (newFact.isNotBlank()) { s.memRaw = Mem.add(s.memRaw, newFact); newFact = "" } }) { Text("Add", color = accent) }
        }
        Panel("What Neko remembers (${facts.size})") {
            if (facts.isEmpty()) Text("Nothing yet.", color = Muted, fontSize = 13.sp)
            facts.forEach { f ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text(f, color = Color.White, fontSize = 14.sp, modifier = Modifier.weight(1f))
                    Icon(Icons.Rounded.Close, "Forget", tint = Muted,
                        modifier = Modifier.clip(CircleShape).clickable { s.memRaw = Mem.remove(s.memRaw, f) }.padding(8.dp))
                }
            }
            if (facts.isNotEmpty()) TextButton(onClick = { s.memRaw = "" }) { Text("Forget everything", color = accent) }
        }
        Text("Everything is stored on this phone only. You can also say “Remember that I love anime” in the chat.", color = Muted, fontSize = 12.sp)
    }
}

// ---------- shared: notification permission ----------

@Composable
private fun NotifPermission(accent: Color) {
    if (Build.VERSION.SDK_INT < 33) return
    val ctx = LocalContext.current
    var granted by remember { mutableStateOf(ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted = it }
    if (!granted) Panel {
        Text("Neko needs permission to show notifications.", color = Color.White, fontSize = 13.sp)
        TextButton(onClick = { launcher.launch(Manifest.permission.POST_NOTIFICATIONS) }) { Text("Allow notifications", color = accent) }
    }
}

@Composable
private fun StepRow(label: String, value: String, accent: Color, onMinus: () -> Unit, onPlus: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Muted, fontSize = 13.sp, modifier = Modifier.weight(1f))
        Box(Modifier.size(36.dp).clip(CircleShape).background(Color(0x14FFFFFF)).clickable(onClick = onMinus), contentAlignment = Alignment.Center) {
            Text("−", color = Color.White, fontSize = 20.sp)
        }
        Text(value, color = accent, fontSize = 16.sp, fontWeight = FontWeight.Bold, modifier = Modifier.width(64.dp), textAlign = androidx.compose.ui.text.style.TextAlign.Center)
        Box(Modifier.size(36.dp).clip(CircleShape).background(Color(0x14FFFFFF)).clickable(onClick = onPlus), contentAlignment = Alignment.Center) {
            Text("+", color = Color.White, fontSize = 20.sp)
        }
    }
}

// ---------- Daily check-in ----------

@Composable
fun CheckInSheet(s: NekoSettings, onDone: () -> Unit) {
    val ctx = LocalContext.current
    val accent = s.currentSkin.edge
    fun reschedule() = CheckIn.schedule(ctx, s.prefs)
    NekoSheet("Daily check-in", onDone) {
        NotifPermission(accent)
        Panel {
            ToggleRow("Daily check-in", "A friendly “how was your day?” notification", s.flag("ci_on"), accent) { s.setFlag("ci_on", it); reschedule() }
        }
        Panel("Time · ${clock(s.ciHour, s.ciMin)}") {
            StepRow("Hour", "${((s.ciHour + 11) % 12) + 1} ${if (s.ciHour < 12) "AM" else "PM"}", accent,
                { s.ciHour = (s.ciHour + 23) % 24; reschedule() }, { s.ciHour = (s.ciHour + 1) % 24; reschedule() })
            StepRow("Minute", String.format("%02d", s.ciMin), accent,
                { s.ciMin = (s.ciMin + 55) % 60; reschedule() }, { s.ciMin = (s.ciMin + 5) % 60; reschedule() })
        }
        Panel {
            TextButton(onClick = { CheckIn.post(ctx, s.prefs) }) { Text("Send a test now", color = accent) }
            Text("Tap the notification to chat. With Neko switched on, it opens the chat right away.", color = Muted, fontSize = 12.sp)
        }
    }
}

// ---------- Reminders ----------

@Composable
fun RemindersSheet(s: NekoSettings, onDone: () -> Unit) {
    val ctx = LocalContext.current
    val accent = s.currentSkin.edge
    var list by remember { mutableStateOf(Reminders.all(ctx)) }
    var text by remember { mutableStateOf("") }
    val presets = listOf("In 10 min", "In 30 min", "In 1 hour", "Tomorrow 9 AM")
    var pick by remember { mutableStateOf(presets[0]) }
    val fmt = remember { SimpleDateFormat("EEE d MMM, h:mm a", Locale.getDefault()) }

    NekoSheet("Reminders", onDone) {
        NotifPermission(accent)
        Panel("New reminder") {
            OutlinedTextField(text, { text = it }, label = { Text("What should I remind you?") }, singleLine = true,
                colors = fieldColors(accent), modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            PillRow(presets, pick, accent) { pick = it }
            TextButton(onClick = {
                val now = System.currentTimeMillis()
                val at = when (pick) {
                    presets[0] -> now + 10 * 60_000L
                    presets[1] -> now + 30 * 60_000L
                    presets[2] -> now + 60 * 60_000L
                    else -> LocalDate.now().plusDays(1).atTime(9, 0).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
                }
                Reminders.add(ctx, at, text.ifBlank { "Reminder" }); text = ""; list = Reminders.all(ctx)
            }) { Text("Add reminder", color = accent) }
        }
        Panel("Upcoming (${list.size})") {
            if (list.isEmpty()) Text("Nothing scheduled.", color = Muted, fontSize = 13.sp)
            list.forEach { r ->
                Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(r.text, color = Color.White, fontSize = 14.sp)
                        Text(fmt.format(Date(r.at)), color = Muted, fontSize = 12.sp)
                    }
                    Icon(Icons.Rounded.Close, "Delete", tint = Muted,
                        modifier = Modifier.clip(CircleShape).clickable { Reminders.remove(ctx, r.id); list = Reminders.all(ctx) }.padding(8.dp))
                }
            }
        }
        Text("You can also type in the chat: “remind me in 10 minutes to drink water”.", color = Muted, fontSize = 12.sp)
    }
}

// ---------- Cat growth ----------

@Composable
fun GrowthSheet(s: NekoSettings, onDone: () -> Unit) {
    val accent = s.currentSkin.edge
    LaunchedEffect(Unit) { s.reloadGrowth() }   // the floating chat earns XP while the app is away
    val lvl = s.level
    val max = lvl >= Growth.MAX_LEVEL
    val into = s.xp - Growth.need(lvl)
    val span = if (max) 1 else Growth.need(lvl + 1) - Growth.need(lvl)
    val progress = if (max) 1f else (into.toFloat() / span).coerceIn(0f, 1f)
    val today = LocalDate.now().toEpochDay().toInt()
    val lastDay = s.prefs.getInt("xpDay", -1)
    val todayXp = if (lastDay == today) s.prefs.getInt("xpToday", 0) else 0
    val streak = if (lastDay >= today - 1) s.streak else 0
    val on = s.flag("f_growth")

    NekoSheet("Cat growth", onDone) {
        Panel {
            ToggleRow("Cat growth", "Neko levels up and unlocks looks as you chat", on, accent) { s.setFlag("f_growth", it) }
        }
        if (on) {
            Box(Modifier.fillMaxWidth().height(150.dp), contentAlignment = Alignment.Center) {
                CatFace(true, s.currentSkin.hue, Modifier.size(width = (150 * s.growScale).dp, height = (128 * s.growScale).dp), accessory = s.accessory)
            }
            Text("Level $lvl · ${Growth.title(lvl)}", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.fillMaxWidth(), textAlign = androidx.compose.ui.text.style.TextAlign.Center)
            Spacer(Modifier.height(10.dp))
            LinearProgressIndicator(progress = { progress }, color = accent, trackColor = Color(0x22FFFFFF), modifier = Modifier.fillMaxWidth().height(8.dp).clip(CircleShape))
            Spacer(Modifier.height(6.dp))
            Text(if (max) "Max level! ${s.xp} XP in total" else "$into / $span XP to level ${lvl + 1}", color = Muted, fontSize = 12.sp, modifier = Modifier.fillMaxWidth(), textAlign = androidx.compose.ui.text.style.TextAlign.Center)
            Spacer(Modifier.height(14.dp))
            Panel("Today") {
                Text("🔥 ${streak}-day streak · $todayXp / ${Growth.DAILY_CAP} XP earned today", color = Color.White, fontSize = 13.sp)
            }
            Panel("Looks") {
                val unlocked = Growth.accessories.filter { it.unlock <= lvl }
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Pill("Auto", s.equip == -1, accent) { s.equip = -1 }
                    Pill("None", s.equip == 0, accent) { s.equip = 0 }
                    Growth.accessories.forEach { a ->
                        if (a.unlock <= lvl) Pill("${a.emoji} ${a.name}", s.equip == a.id, accent) { s.equip = a.id }
                        else Pill("🔒 ${a.name} · Lv ${a.unlock}", false, Color(0x33FFFFFF)) {}
                    }
                }
                Spacer(Modifier.height(8.dp))
                val next = Growth.accessories.firstOrNull { it.unlock > lvl }
                Text(if (next != null) "Next look: ${next.name} at level ${next.unlock}." else "You unlocked every look!", color = Muted, fontSize = 12.sp)
            }
            Panel("How to earn XP") {
                Text("• Chat with Neko: +2 per reply\n• Smart reply, translate, screenshots, reminders and other skills: +3\n• First chat of the day: +5 bonus\n• Up to ${Growth.DAILY_CAP} XP a day, so come back daily", color = Muted, fontSize = 13.sp)
            }
            Text("Neko starts small and grows to full size at level ${Growth.MAX_LEVEL}.", color = Muted, fontSize = 12.sp)
        }
    }
}

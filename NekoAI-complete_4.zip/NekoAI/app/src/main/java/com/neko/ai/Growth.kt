package com.neko.ai

import android.content.SharedPreferences
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import java.time.LocalDate

data class Accessory(val id: Int, val name: String, val unlock: Int, val emoji: String)

/** Neko levels up as you use it: XP, levels, a growing cat and looks to unlock. All stored in the same prefs. */
object Growth {
    const val MAX_LEVEL = 10
    const val DAILY_CAP = 80

    val accessories = listOf(
        Accessory(1, "Bow", 2, "🎀"), Accessory(2, "Headphones", 3, "🎧"), Accessory(3, "Shades", 4, "😎"),
        Accessory(4, "Crown", 6, "👑"), Accessory(5, "Halo", 8, "😇")
    )

    /** Total XP needed to reach [level]. */
    fun need(level: Int) = 15 * level * (level - 1) / 2
    fun level(xp: Int): Int { var l = 1; while (l < MAX_LEVEL && xp >= need(l + 1)) l++; return l }
    fun title(l: Int) = when { l <= 2 -> "Kitten"; l <= 4 -> "Street cat"; l <= 6 -> "Cool cat"; l <= 9 -> "Neko master"; else -> "Neko legend" }
    /** The cat looks smaller while young and reaches full size at the top level. */
    fun scale(l: Int) = 0.84f + 0.16f * (l - 1) / (MAX_LEVEL - 1)

    fun on(p: SharedPreferences) = p.flag("f_growth")
    fun levelOf(p: SharedPreferences) = level(p.getInt("xp", 0))
    fun drawScale(p: SharedPreferences) = if (on(p)) scale(levelOf(p)) else 1f

    /** equip: -1 = newest unlocked look (auto), 0 = none, otherwise that look if unlocked. */
    fun equippedFor(level: Int, equip: Int): Int {
        val unlocked = accessories.filter { it.unlock <= level }
        return when {
            equip == -1 -> unlocked.lastOrNull()?.id ?: 0
            equip == 0 -> 0
            unlocked.any { it.id == equip } -> equip
            else -> 0
        }
    }
    fun equipped(p: SharedPreferences) = if (!on(p)) 0 else equippedFor(levelOf(p), p.getInt("equip", -1))

    fun unlockText(level: Int): String =
        accessories.filter { it.unlock == level }.joinToString("") { " New look unlocked: ${it.name} ${it.emoji}. Pick it in Cat growth." }

    class Result(val gained: Int, val leveledUp: Boolean, val level: Int)

    /** Adds XP (with a daily cap and a bonus for the first chat of each day). */
    fun award(p: SharedPreferences, amount: Int): Result {
        val xp0 = p.getInt("xp", 0)
        val before = level(xp0)
        if (!on(p)) return Result(0, false, before)
        val today = LocalDate.now().toEpochDay().toInt()
        val e = p.edit()
        var gain = amount
        var todayXp = p.getInt("xpToday", 0)
        val lastDay = p.getInt("xpDay", -1)
        if (lastDay != today) {
            e.putInt("streak", if (lastDay == today - 1) p.getInt("streak", 0) + 1 else 1)
            e.putInt("xpDay", today)
            todayXp = 0; gain += 5
        }
        val g = minOf(gain, (DAILY_CAP - todayXp).coerceAtLeast(0))
        val xp = xp0 + g
        e.putInt("xp", xp).putInt("xpToday", todayXp + g).apply()
        val after = level(xp)
        return Result(g, after > before, after)
    }

    /** Draws a look on top of the cat artwork. (left, top, w, h) is where the 640x559 artwork sits. */
    fun drawAccessory(c: Canvas, left: Float, top: Float, w: Float, h: Float, id: Int) {
        if (id <= 0) return
        val sx = w / 640f; val sy = h / 559f
        fun x(v: Float) = left + v * sx
        fun y(v: Float) = top + v * sy
        val fill = Paint(Paint.ANTI_ALIAS_FLAG)
        val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = 0xFF120A20.toInt(); strokeWidth = 7f * sx; strokeJoin = Paint.Join.ROUND }
        when (id) {
            1 -> { // bow on the left ear
                fill.color = 0xFFFF5FB8.toInt()
                val p = Path().apply {
                    moveTo(x(175f), y(150f)); lineTo(x(100f), y(100f)); lineTo(x(100f), y(200f)); close()
                    moveTo(x(175f), y(150f)); lineTo(x(250f), y(100f)); lineTo(x(250f), y(200f)); close()
                }
                c.drawPath(p, fill); c.drawPath(p, line)
                c.drawCircle(x(175f), y(150f), 22f * sx, fill); c.drawCircle(x(175f), y(150f), 22f * sx, line)
            }
            2 -> { // headphones
                val band = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 24f * sx; color = 0xFF2B2140.toInt(); strokeCap = Paint.Cap.ROUND }
                c.drawArc(RectF(x(75f), y(40f), x(565f), y(640f)), 190f, 160f, false, band)
                fill.color = 0xFF6D44F0.toInt()
                for (cx in listOf(25f to 95f, 545f to 615f)) {
                    val r = RectF(x(cx.first), y(280f), x(cx.second), y(405f))
                    c.drawRoundRect(r, 22f * sx, 22f * sx, fill); c.drawRoundRect(r, 22f * sx, 22f * sx, line)
                }
            }
            3 -> { // sunglasses
                fill.color = 0xFF0B0714.toInt()
                val l = RectF(x(158f), y(310f), x(284f), y(400f)); val r = RectF(x(350f), y(310f), x(474f), y(400f))
                c.drawRect(x(280f), y(335f), x(354f), y(354f), fill)
                c.drawRoundRect(l, 24f * sx, 24f * sx, fill); c.drawRoundRect(r, 24f * sx, 24f * sx, fill)
                val glint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x66FFFFFF; style = Paint.Style.STROKE; strokeWidth = 9f * sx; strokeCap = Paint.Cap.ROUND }
                c.drawLine(x(185f), y(385f), x(215f), y(330f), glint); c.drawLine(x(380f), y(385f), x(410f), y(330f), glint)
                val rim = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = 0xFFB69CFF.toInt(); strokeWidth = 5f * sx }
                c.drawRoundRect(l, 24f * sx, 24f * sx, rim); c.drawRoundRect(r, 24f * sx, 24f * sx, rim)
            }
            4 -> { // crown
                fill.color = 0xFFF5C84A.toInt()
                val p = Path().apply {
                    moveTo(x(245f), y(150f)); lineTo(x(245f), y(80f)); lineTo(x(282f), y(112f)); lineTo(x(320f), y(62f))
                    lineTo(x(358f), y(112f)); lineTo(x(395f), y(80f)); lineTo(x(395f), y(150f)); close()
                }
                c.drawPath(p, fill); c.drawPath(p, line)
                fill.color = 0xFFFF4D6D.toInt(); c.drawCircle(x(320f), y(122f), 11f * sx, fill)
            }
            5 -> { // halo and sparkles
                val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 26f * sx; color = 0x55FFE08A }
                val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 11f * sx; color = 0xFFFFE08A.toInt() }
                val o = RectF(x(215f), y(10f), x(425f), y(56f))
                c.drawOval(o, glow); c.drawOval(o, ring)
                fill.color = 0xFFFFFFFF.toInt()
                for (p in listOf(120f to 60f, 535f to 85f, 62f to 215f, 585f to 235f)) c.drawRect(x(p.first), y(p.second), x(p.first + 16f), y(p.second + 16f), fill)
            }
        }
    }
}

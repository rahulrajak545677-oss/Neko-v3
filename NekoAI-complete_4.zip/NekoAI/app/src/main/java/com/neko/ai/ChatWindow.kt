package com.neko.ai

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.rounded.CameraAlt
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.DoneAll
import androidx.compose.material.icons.rounded.Headset
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.Remove
import androidx.compose.material.icons.rounded.Verified
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.scale
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

data class Msg(val mine: Boolean, val text: String, val shot: Bitmap? = null)

@Composable
fun ChatWindow(state: ChatState, voice: VoiceInput, speaker: Speaker, skin: Skin, onMinimize: () -> Unit, onClose: () -> Unit, onWantInput: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val list = rememberLazyListState()
    val focus = remember { FocusRequester() }
    val keyboard = LocalSoftwareKeyboardController.current
    val haptic = rememberHaptic(state.flag("f_haptic"))
    val Edge = skin.edge
    val showCam = state.flag("f_shot")
    val showMic = state.flag("f_voice")
    val chips = state.chips()
    var text by remember { mutableStateOf("") }
    val shape = RoundedCornerShape(30.dp)

    LaunchedEffect(state.msgs.size, state.typing) {
        val last = state.msgs.size - 1 + (if (state.typing) 1 else 0)
        list.animateScrollToItem(last.coerceAtLeast(0))
    }
    DisposableEffect(Unit) { onDispose { voice.stop(); speaker.stop() } }
    var talk by remember { mutableStateOf(false) }   // hands-free conversation: listen, answer out loud, listen again
    val speakOn = state.flag("f_speak")

    fun send() {
        val t = text.trim()
        if (t.isEmpty() && state.attached == null) return
        voice.stop(); speaker.stop(); haptic()
        text = ""; scope.launch { state.send(t) }
    }
    fun startListening() {
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            talk = false
            state.msgs.add(Msg(false, "Allow the Mic chip in the Neko app first.")); return
        }
        if (voice.listening) return
        voice.start(
            onPartial = { text = it },
            onFinal = { text = it; send() },
            onError = { talk = false; state.msgs.add(Msg(false, it)) }   // a failed listen ends the hands-free loop
        )
    }
    fun toggleMic() { haptic(); speaker.stop(); if (voice.listening) voice.stop() else startListening() }
    fun toggleTalk() {
        haptic()
        talk = !talk
        if (talk) { speaker.stop(); startListening() } else { voice.stop(); speaker.stop() }
    }

    // Speak each new reply when "Speak replies" or Talk mode is on; in Talk mode listen again afterwards.
    val firstReplyId = remember { state.replyId }   // replies from before this window opened are not read out again
    LaunchedEffect(state.replyId) {
        if (state.replyId > firstReplyId && (talk || speakOn)) {
            speaker.speak(state.lastReply) { if (talk) startListening() }
        }
    }

    Column(
        Modifier.fillMaxSize()
            .drawBehind {   // pixel sparkles around the card, like the design
                val px = 5.dp.toPx()
                listOf(Offset(.97f, .02f), Offset(.02f, .05f), Offset(.99f, .93f), Offset(.04f, .98f)).forEachIndexed { i, o ->
                    drawRect(Edge.copy(alpha = if (i % 2 == 0) .9f else .5f), Offset(o.x * size.width, o.y * size.height), Size(px, px))
                }
            }
            .clip(shape).background(ChatBg)
            .border(2.dp, Brush.linearGradient(listOf(Edge, androidx.compose.ui.graphics.lerp(Edge, Color.White, 0.35f), Edge)), shape)
    ) {
        // Header
        Row(
            Modifier.fillMaxWidth().padding(start = 14.dp, end = 10.dp, top = 12.dp, bottom = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            val react = state.flag("f_react")
            val catRot = remember { Animatable(0f) }
            val catScale = remember { Animatable(1f) }
            LaunchedEffect(state.typing, react) {
                if (state.typing && react) { while (true) { catRot.animateTo(9f, tween(170)); catRot.animateTo(-9f, tween(170)) } }
                else catRot.animateTo(0f, tween(120))
            }
            LaunchedEffect(state.replyId, react) {
                if (react && state.replyId > firstReplyId) {
                    catScale.animateTo(1.25f, spring(dampingRatio = Spring.DampingRatioMediumBouncy)); catScale.animateTo(1f)
                }
            }
            Box(Modifier.size(width = 46.dp, height = 42.dp).graphicsLayer { rotationZ = catRot.value; scaleX = catScale.value; scaleY = catScale.value }) {
                CatFace(true, skin.hue, Modifier.fillMaxSize(), accessory = Growth.equipped(ctx.getSharedPreferences("neko", Context.MODE_PRIVATE)))
                Box(Modifier.size(12.dp).align(Alignment.BottomEnd).background(Color(0xFF22C55E), CircleShape))
            }
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Neko AI", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    Spacer(Modifier.width(6.dp))
                    Icon(Icons.Rounded.Verified, "Verified", tint = Edge, modifier = Modifier.size(18.dp))
                }
                Text("Online", color = Online, fontSize = 13.sp)
            }
            if (showMic) Box(
                Modifier.size(38.dp).background(if (talk) skin.bubble else Color.Transparent, CircleShape).clickable { toggleTalk() },
                contentAlignment = Alignment.Center
            ) { Icon(Icons.Rounded.Headset, "Talk mode", tint = Color.White, modifier = Modifier.size(22.dp)) }
            Icon(Icons.Rounded.Remove, "Minimize", tint = Color.White, modifier = Modifier.clip(CircleShape).clickable(onClick = onMinimize).padding(8.dp).size(22.dp))
            Icon(Icons.Rounded.Close, "Close", tint = Color.White, modifier = Modifier.clip(CircleShape).clickable(onClick = onClose).padding(8.dp).size(22.dp))
        }

        // Messages
        LazyColumn(
            Modifier.weight(1f).fillMaxWidth(), state = list,
            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(state.msgs) { MessageRow(it, skin) }
            if (state.typing) item { TypingDots(skin) }
        }

        // Smart reply choices
        if (state.options.isNotEmpty()) Column(
            Modifier.fillMaxWidth().heightIn(max = 200.dp).verticalScroll(rememberScrollState()).padding(horizontal = 14.dp, vertical = 4.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            state.options.forEach { o ->
                Column(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Color(0x1AFFFFFF))
                        .border(1.dp, Edge.copy(alpha = .6f), RoundedCornerShape(16.dp))
                        .clickable {
                            haptic()
                            state.useOption(o.text) { t ->
                                (ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("Neko", t))
                            }
                        }.padding(horizontal = 14.dp, vertical = 8.dp)
                ) {
                    Text(o.label.uppercase(), color = Edge, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                    Text(o.text, color = Color.White, fontSize = 14.sp)
                }
            }
            Text("Dismiss", color = Online, fontSize = 12.sp, modifier = Modifier.clickable { state.dismissOptions() }.padding(vertical = 4.dp))
        }

        // Quick replies
        if (chips.isNotEmpty()) LazyRow(
            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(chips) { c ->
                Box(
                    Modifier.clip(CircleShape).border(1.dp, Edge.copy(alpha = .8f), CircleShape)
                        .clickable { haptic(); scope.launch { state.onChip(c) } }
                        .padding(horizontal = 14.dp, vertical = 8.dp)
                ) { Text(c, color = Color.White, fontSize = 13.sp) }
            }
        }

        // Attached screenshot preview
        state.attached?.let { shot ->
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 2.dp).clip(RoundedCornerShape(16.dp))
                    .background(Color(0x1AFFFFFF)).padding(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Image(shot.asImageBitmap(), "Screenshot", Modifier.height(44.dp).clip(RoundedCornerShape(8.dp)), contentScale = ContentScale.Fit)
                Spacer(Modifier.width(10.dp))
                Text("Screen attached. Ask me about it.", color = Color.White, fontSize = 12.sp, modifier = Modifier.weight(1f))
                Icon(Icons.Rounded.Close, "Remove screenshot", tint = Online, modifier = Modifier.clip(CircleShape).clickable { state.clearAttachment() }.padding(6.dp).size(18.dp))
            }
        }

        // Input pill: camera | message | mic | send
        val pill = RoundedCornerShape(32.dp)
        Row(
            Modifier.fillMaxWidth().padding(12.dp).clip(pill).background(Color(0xFF0E0A1C)).border(1.5.dp, Edge, pill).padding(5.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (showCam) {
                RoundIcon(Icons.Rounded.CameraAlt, "Capture screen", skin.bubble) { haptic(); scope.launch { state.attachScreenshot() } }
                Spacer(Modifier.width(10.dp))
            } else Spacer(Modifier.width(12.dp))
            BasicTextField(
                value = text, onValueChange = { text = it }, singleLine = true,
                textStyle = TextStyle(color = Color.White, fontSize = 15.sp),
                cursorBrush = SolidColor(Color.White),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = { send() }),
                modifier = Modifier.weight(1f).focusRequester(focus).pointerInput(Unit) {
                    // The overlay window starts non-focusable; make it focusable, then summon the keyboard.
                    awaitEachGesture {
                        awaitFirstDown(requireUnconsumed = false)
                        onWantInput()
                        scope.launch { delay(150); focus.requestFocus(); keyboard?.show() }
                    }
                },
                decorationBox = { inner ->
                    if (text.isEmpty()) Text(if (voice.listening) "Listening…" else if (talk) "Talk mode on" else "Message…", color = Online, fontSize = 15.sp)
                    inner()
                }
            )
            if (showMic) {
                Box(Modifier.padding(horizontal = 6.dp).width(1.dp).height(24.dp).background(Color(0x44FFFFFF)))
                MicBtn(voice.listening, skin.bubble) { toggleMic() }
                Spacer(Modifier.width(4.dp))
            }
            RoundIcon(Icons.AutoMirrored.Rounded.Send, "Send", skin.bubble) { send() }
        }
    }
}

@Composable
private fun RoundIcon(icon: androidx.compose.ui.graphics.vector.ImageVector, desc: String, color: Color, onClick: () -> Unit) {
    Box(Modifier.size(42.dp).background(color, CircleShape).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        Icon(icon, desc, tint = Color.White, modifier = Modifier.size(21.dp))
    }
}

@Composable
private fun MicBtn(listening: Boolean, color: Color, onClick: () -> Unit) {
    val t = rememberInfiniteTransition(label = "mic")
    val pulse by t.animateFloat(1f, 1.18f, infiniteRepeatable(tween(550), RepeatMode.Reverse), label = "pulse")
    Box(
        Modifier.size(38.dp).scale(if (listening) pulse else 1f)
            .background(if (listening) color else Color.Transparent, CircleShape).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Icon(Icons.Rounded.Mic, "Voice input", tint = Color.White, modifier = Modifier.size(22.dp)) }
}

@Composable
private fun MessageRow(m: Msg, skin: Skin) {
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = if (m.mine) Arrangement.End else Arrangement.Start,
        verticalAlignment = Alignment.Bottom
    ) {
        if (!m.mine) { CatFace(true, skin.hue, Modifier.size(width = 34.dp, height = 30.dp)); Spacer(Modifier.width(8.dp)) }
        val bubble = if (m.mine) RoundedCornerShape(22.dp, 22.dp, 4.dp, 22.dp) else RoundedCornerShape(22.dp, 22.dp, 22.dp, 4.dp)
        Box(
            Modifier.widthIn(max = 270.dp).clip(bubble).background(if (m.mine) skin.bubble else BotBubble)
                .padding(horizontal = 16.dp, vertical = 10.dp)
        ) {
            Column {
                m.shot?.let {
                    Image(it.asImageBitmap(), "Screenshot", Modifier.fillMaxWidth().heightIn(max = 140.dp).clip(RoundedCornerShape(10.dp)), contentScale = ContentScale.Fit)
                    Spacer(Modifier.height(6.dp))
                }
                Row(verticalAlignment = Alignment.Bottom) {
                    Text(m.text, color = Color.White, fontSize = 15.sp, modifier = Modifier.weight(1f, fill = false))
                    if (m.mine) {
                        Spacer(Modifier.width(6.dp))
                        Icon(Icons.Rounded.DoneAll, null, tint = Color(0xB3FFFFFF), modifier = Modifier.size(14.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun TypingDots(skin: Skin) {
    val t = rememberInfiniteTransition(label = "dots")
    Row(verticalAlignment = Alignment.Bottom) {
        CatFace(true, skin.hue, Modifier.size(width = 34.dp, height = 30.dp)); Spacer(Modifier.width(8.dp))
        Row(Modifier.clip(RoundedCornerShape(22.dp)).background(BotBubble).padding(horizontal = 18.dp, vertical = 16.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            repeat(3) { i ->
                val a by t.animateFloat(0.25f, 1f, infiniteRepeatable(tween(500, delayMillis = i * 150), RepeatMode.Reverse), label = "d$i")
                Box(Modifier.size(8.dp).alpha(a).background(Color(0xFFD9D3F5), CircleShape))
            }
        }
    }
}

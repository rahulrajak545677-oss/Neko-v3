package com.neko.ai

import android.content.SharedPreferences
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.Color
import kotlin.math.cos
import kotlin.math.sin
import kotlin.reflect.KProperty

/** A neon colour for the cat. [hue] rotates the cat artwork's violet/pink to match. */
data class Skin(val name: String, val edge: Color, val bubble: Color, val hue: Float)
data class Feature(val key: String, val title: String, val sub: String, val default: Boolean)

object Cfg {
    val skins = listOf(
        Skin("Violet", Color(0xFF7C5CFF), Color(0xFF6D44F0), 0f),
        Skin("Cyan", Color(0xFF22D3EE), Color(0xFF0891B2), -71f),
        Skin("Pink", Color(0xFFF472B6), Color(0xFFDB2777), 72f),
        Skin("Green", Color(0xFF4ADE80), Color(0xFF16A34A), -116f),
        Skin("Orange", Color(0xFFFB923C), Color(0xFFEA580C), 129f)
    )
    val moods = listOf("Happy", "Sleepy", "Excited", "Thinking")
    val personas = listOf("Cute", "Serious", "Funny", "Coach")
    val corners = listOf("Top left", "Top right", "Bottom left", "Bottom right")
    val tones = listOf("Professional", "Casual", "Friendly", "Funny")
    val languages = listOf("English", "Hindi", "Hinglish", "Spanish", "French", "Arabic")
    val lengths = listOf("Short", "Normal", "Detailed")
    val tlangs = listOf("English", "Hindi", "Spanish", "French", "German", "Portuguese", "Arabic", "Bengali", "Japanese", "Korean")

    val features = listOf(
        Feature("f_growth", "Cat growth", "Neko levels up and unlocks looks as you chat", true),
        Feature("f_friend", "Friend chat", "Casual daily talk that remembers the conversation", true),
        Feature("f_speak", "Speak replies", "Neko reads answers out loud", false),
        Feature("f_smart", "Smart reply", "3 reply ideas for the message on screen", true),
        Feature("f_translate", "Translate screen", "Translate what you see into your language", true),
        Feature("f_remind", "Reminders from chat", "Say “remind me in 10 minutes to…”", true),
        Feature("f_memory", "Remember me", "Neko remembers things you tell it", true),
        Feature("f_history", "Save chat history", "Keep conversations to read later", true),
        Feature("f_react", "Cat reactions", "The cat breathes, bounces and sleeps", true),
        Feature("f_write", "Fix my writing", "Make it professional, shorter or fun", true),
        Feature("f_apply", "Apply to text field", "Paste the rewrite back into the app", true),
        Feature("f_explain", "Explain screen", "Reads the text on screen when you ask", true),
        Feature("f_shot", "Screenshot questions", "Camera button and “Look at screen”", true),
        Feature("f_voice", "Voice input", "Talk to Neko with the mic button", true),
        Feature("f_search", "Web search", "Needs a free TinyFish key", true),
        Feature("f_links", "Read links", "Paste a link and Neko reads the page", true),
        Feature("f_task", "Web tasks", "Neko operates a website for you. Uses TinyFish credits", false),
        Feature("f_chips", "Quick reply chips", "Shortcut buttons above the message box", true),
        Feature("f_haptic", "Haptic taps", "A tiny buzz on buttons", true)
    )
    val privacyDefaults = mapOf("p_screen" to true, "p_mask" to true, "p_clear" to true, "m_auto" to true, "ci_on" to false)
    val defaults: Map<String, Boolean> = features.associate { it.key to it.default } + privacyDefaults

    val presetApps = listOf(
        "com.whatsapp", "com.instagram.android", "com.android.chrome", "com.google.android.youtube",
        "org.telegram.messenger", "com.google.android.apps.messaging"
    )

    fun skin(i: Int) = skins[i.coerceIn(0, skins.lastIndex)]

    /** Standard hue-rotate colour matrix (4x5, row major). */
    fun hueMatrix(deg: Float): FloatArray {
        val r = Math.toRadians(deg.toDouble())
        val c = cos(r).toFloat(); val s = sin(r).toFloat()
        return floatArrayOf(
            0.213f + c * 0.787f - s * 0.213f, 0.715f - c * 0.715f - s * 0.715f, 0.072f - c * 0.072f + s * 0.928f, 0f, 0f,
            0.213f - c * 0.213f + s * 0.143f, 0.715f + c * 0.285f + s * 0.140f, 0.072f - c * 0.072f - s * 0.283f, 0f, 0f,
            0.213f - c * 0.213f - s * 0.787f, 0.715f - c * 0.715f + s * 0.715f, 0.072f + c * 0.928f + s * 0.072f, 0f, 0f,
            0f, 0f, 0f, 1f, 0f
        )
    }
}

fun SharedPreferences.flag(key: String): Boolean = getBoolean(key, Cfg.defaults[key] ?: true)

// ---- Compose-observable, write-through preference delegates ----
class PrefInt(private val p: SharedPreferences, private val k: String, d: Int) {
    private val s = mutableIntStateOf(p.getInt(k, d))
    operator fun getValue(t: Any?, prop: KProperty<*>) = s.intValue
    operator fun setValue(t: Any?, prop: KProperty<*>, v: Int) { s.intValue = v; p.edit().putInt(k, v).apply() }
}
class PrefBool(private val p: SharedPreferences, private val k: String, d: Boolean) {
    private val s = mutableStateOf(p.getBoolean(k, d))
    operator fun getValue(t: Any?, prop: KProperty<*>) = s.value
    operator fun setValue(t: Any?, prop: KProperty<*>, v: Boolean) { s.value = v; p.edit().putBoolean(k, v).apply() }
}
class PrefStr(private val p: SharedPreferences, private val k: String, d: String) {
    private val s = mutableStateOf(p.getString(k, d).orEmpty())
    operator fun getValue(t: Any?, prop: KProperty<*>) = s.value
    operator fun setValue(t: Any?, prop: KProperty<*>, v: String) { s.value = v; p.edit().putString(k, v).apply() }
}
class PrefSet(private val p: SharedPreferences, private val k: String, d: Set<String>) {
    private val s = mutableStateOf(p.getStringSet(k, d)?.toSet() ?: d)
    operator fun getValue(t: Any?, prop: KProperty<*>): Set<String> = s.value
    operator fun setValue(t: Any?, prop: KProperty<*>, v: Set<String>) { s.value = v; p.edit().putStringSet(k, v).apply() }
}

/** Everything the user can change, observable by Compose and saved to the same prefs the service reads. */
class NekoSettings(val prefs: SharedPreferences) {
    var skin by PrefInt(prefs, "skin", 0)
    var mood by PrefInt(prefs, "mood", 0)
    var persona by PrefInt(prefs, "persona", 0)
    var size by PrefInt(prefs, "size", 64)
    var corner by PrefInt(prefs, "corner", 1)
    var fade by PrefBool(prefs, "fade", true)
    var fadeAlpha by PrefInt(prefs, "fadeAlpha", 30)
    var tone by PrefStr(prefs, "tone", "Friendly")
    var lang by PrefStr(prefs, "lang", "English")
    var length by PrefStr(prefs, "length", "Normal")
    var model by PrefStr(prefs, "model", GeminiClient.DEFAULT_MODEL)
    var key by PrefStr(prefs, "key", "")
    var tfKey by PrefStr(prefs, "tfKey", "")
    var only by PrefBool(prefs, "only", false)
    var apps by PrefSet(prefs, "apps", emptySet())
    var xp by PrefInt(prefs, "xp", 0)
    var streak by PrefInt(prefs, "streak", 0)
    var equip by PrefInt(prefs, "equip", -1)
    var tlang by PrefStr(prefs, "tlang", "English")
    var memRaw by PrefStr(prefs, "mem", "")
    var ciHour by PrefInt(prefs, "ciHour", 20)
    var ciMin by PrefInt(prefs, "ciMin", 0)

    private val flags = mutableStateMapOf<String, Boolean>().apply { Cfg.defaults.keys.forEach { put(it, prefs.flag(it)) } }
    fun flag(k: String) = flags[k] ?: true
    fun setFlag(k: String, v: Boolean) { flags[k] = v; prefs.edit().putBoolean(k, v).apply() }

    val currentSkin get() = Cfg.skin(skin)
    val level get() = Growth.level(xp)
    val accessory get() = if (!flag("f_growth")) 0 else Growth.equippedFor(Growth.level(xp), equip)
    val growScale get() = if (!flag("f_growth")) 1f else Growth.scale(Growth.level(xp))
    /** The chat in the floating window changes XP in the prefs; pull the latest values. */
    fun reloadGrowth() { xp = prefs.getInt("xp", 0); streak = prefs.getInt("streak", 0) }
    val featuresOn get() = Cfg.features.count { flag(it.key) }
}

package com.neko.ai

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** A safe playground inside the app: a fake app with a sample draft, and the real chat window on top of it. */
@Composable
fun TryNeko(s: NekoSettings, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val skin = s.currentSkin
    var sample by remember { mutableStateOf("Hello, could you please send me the report at your earliest convenience? Thank you.") }
    val ai = remember { AiHelper(s.prefs) }
    val voice = remember { VoiceInput(ctx) { ai.langTag() } }
    val speaker = remember { Speaker(ctx) { ai.langTag() } }
    val chat = remember {
        ChatState(
            ai,
            appCtx = ctx.applicationContext,
            capture = { throw NekoException("Screen capture works over other apps. Switch Neko on and try it anywhere.") },
            draft = { sample }, screenText = { sample }, apply = { sample = it; true }
        )
    }
    DisposableEffect(Unit) { onDispose { voice.destroy(); speaker.destroy() } }

    Column(
        Modifier.fillMaxSize().background(Void).statusBarsPadding().navigationBarsPadding().imePadding().padding(16.dp)
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("Try Neko", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Icon(Icons.Rounded.Close, "Close", tint = Color.White, modifier = Modifier.clip(CircleShape).clickable(onClick = onBack).padding(8.dp))
        }
        Spacer(Modifier.height(10.dp))
        Box(Modifier.weight(1f).fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Color(0x0DFFFFFF)).border(1.dp, Color(0x22FFFFFF), RoundedCornerShape(20.dp))) {
            // the "other app": a header banner and a message box holding the sample draft
            Column(Modifier.fillMaxSize().padding(12.dp)) {
                Box(Modifier.fillMaxWidth().height(70.dp).clip(RoundedCornerShape(14.dp)).background(Brush.verticalGradient(listOf(Color(0xFF8B1E2E), Color(0xFF2A0A12)))))
                Spacer(Modifier.height(10.dp))
                Text("Sample draft (editable)", color = Muted, fontSize = 11.sp)
                Spacer(Modifier.height(4.dp))
                Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Color(0x14FFFFFF)).padding(12.dp)) {
                    BasicTextField(
                        sample, { sample = it }, textStyle = TextStyle(color = Color.White, fontSize = 14.sp),
                        cursorBrush = SolidColor(skin.edge), modifier = Modifier.fillMaxWidth()
                    )
                }
            }
            Box(Modifier.align(Alignment.BottomCenter).fillMaxWidth(.96f).fillMaxHeight(.74f).padding(bottom = 8.dp)) {
                ChatWindow(chat, voice, speaker, skin, onMinimize = {}, onClose = onBack, onWantInput = {})
            }
        }
        Spacer(Modifier.height(10.dp))
        Text("Tap a quick action on the sample draft, then “Apply to text field” to see it replaced. Needs your Gemini key in AI brain.",
            color = Muted, fontSize = 12.sp)
    }
}

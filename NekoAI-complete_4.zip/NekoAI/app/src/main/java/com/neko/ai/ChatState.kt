package com.neko.ai

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.os.Build
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter

class ReplyOption(val label: String, val text: String)

/**
 * One conversation. [capture] hides Neko's windows and grabs the screen (BubbleService provides it).
 * [draft], [screenText] and [apply] default to the accessibility service; Try Neko swaps in its sample draft.
 * With a [store], every finished reply is saved so the chat shows up in Chat history.
 */
class ChatState(
    private val ai: AiHelper,
    private val capture: suspend () -> Bitmap,
    private val appCtx: Context,
    private val draft: () -> String? = { NekoAccessibilityService.draft },
    private val screenText: () -> String? = { NekoAccessibilityService.screen },
    private val apply: (String) -> Boolean = { NekoAccessibilityService.setDraft(it) },
    private val store: HistoryStore? = null,
    saved: SavedChat? = null
) {
    val id: String = saved?.id ?: java.util.UUID.randomUUID().toString()
    val msgs = mutableStateListOf<Msg>().also { l ->
        if (saved != null) saved.msgs.forEach { l.add(Msg(it.mine, it.text)) } else l.add(Msg(false, greeting(ai.mood())))
    }
    fun flag(k: String) = ai.flag(k)
    var typing by mutableStateOf(false)
    var replyId by mutableIntStateOf(0)       // bumps on every successful reply; the window uses it to speak and react
        private set
    var lastReply = ""
        private set
    var attached by mutableStateOf<Bitmap?>(null)          // screenshot waiting to be sent with the next message
        private set
    var options by mutableStateOf<List<ReplyOption>>(emptyList())   // Smart reply choices
        private set
    private var pending by mutableStateOf<String?>(null)   // last rewrite, waiting to be applied
    private var mode by mutableStateOf<String?>(null)      // "search", "task" or "remind": the next message is the query
    private var exchanges = 0

    // chat memory for Friend chat: (true = user, false = Neko). Always starts with the user so roles alternate.
    private val turns = mutableListOf<Pair<Boolean, String>>().also { t ->
        saved?.msgs?.forEach { m -> if (t.isEmpty()) { if (m.mine) t.add(true to m.text) } else if (t.last().first != m.mine) t.add(m.mine to m.text) }
        if (t.isNotEmpty() && t.last().first) t.removeAt(t.lastIndex)
        while (t.size > 16) { t.removeAt(0); t.removeAt(0) }
    }

    private val starters = linkedMapOf(
        "☀️ Say good morning" to "Good morning Neko!",
        "😂 Tell me a joke" to "Tell me a joke!",
        "💜 Cheer me up" to "I'm feeling a bit down today. Can you cheer me up?",
        "🗣️ Practice English" to "Let's practice English conversation. Talk to me casually and gently correct my mistakes.",
        "🍜 What should I eat?" to "I can't decide what to eat today. Help me choose!"
    )
    private val urlRe = Regex("https?://\\S+")
    private val rememberRe = Regex("(?is)^\\s*(?:please\\s+)?remember(?:\\s+that)?[:,\\s]+(.{3,})")
    private val remindRe = Regex("(?i)\\b(remind me|set (a )?reminder|reminder for|yaad dila)\\b")
    private val quickRe = Regex("(?i)\\bin\\s+(\\d{1,3})\\s*(minutes?|mins?|hours?|hrs?|h|m)\\b\\s*(?:to|that|for)?\\s*(.*)")
    private val needKey = "Add your TinyFish key first: open AI brain in the Neko app."

    private fun remember(q: String, a: String) {
        turns.add(true to q); turns.add(false to a)
        while (turns.size > 16) { turns.removeAt(0); turns.removeAt(0) }   // keep pairs so roles alternate
    }

    fun chips(): List<String> {
        if (!flag("f_chips")) return emptyList()
        return buildList {
            if (flag("f_friend") && turns.isEmpty()) addAll(starters.keys)
            if (flag("f_write")) { add("Make it professional"); add("Make it shorter"); add("Add emojis ✨") }
            if (flag("f_smart")) add("💬 Smart reply")
            if (flag("f_translate")) add("🔤 Translate screen")
            if (flag("f_remind")) add("⏰ Remind me")
            if (flag("f_explain")) add("Explain screen")
            if (flag("f_shot")) add("📸 Look at screen")
            if (flag("f_search")) add("🔎 Search the web")
            if (flag("f_task")) add("🌐 Web task")
            if (pending != null && flag("f_apply")) add("Apply to text field")
        }
    }

    fun clearAttachment() { attached = null }
    fun dismissOptions() { options = emptyList() }

    /** Used when a notification opens the chat: Neko speaks first. */
    fun botSays(text: String) {
        msgs.add(Msg(false, text))
        turns.add(true to "(Neko opens the chat with a friendly check-in)"); turns.add(false to text)
    }

    /** Smart reply card tapped: put it in the text field, or copy it if that field can't be reached. */
    fun useOption(text: String, copy: (String) -> Unit) {
        if (apply(text)) msgs.add(Msg(false, "Done! Reply added to your text box. ✅"))
        else { copy(text); msgs.add(Msg(false, "Copied. Paste it in your text box.")) }
        options = emptyList()
    }

    /** 📷 button: grab the screen and hold it until the user sends their question. */
    suspend fun attachScreenshot() {
        try { attached = capture() } catch (e: Exception) { msgs.add(Msg(false, e.message ?: "Couldn’t capture the screen.")) }
    }

    suspend fun send(text: String) {
        val shot = attached; attached = null
        val q = text.ifBlank { "What’s on my screen? Help me with it." }
        msgs.add(Msg(true, q, shot?.let { thumb(it) }))
        val m = mode; mode = null
        val learn = reply {
            when {
                shot != null -> ai.ask(q, screenText(), shot)
                m == "search" -> search(q)
                m == "task" -> task(q)
                m == "remind" -> remind(q)
                flag("f_memory") && rememberRe.containsMatchIn(q) -> {
                    ai.addMemory(rememberRe.find(q)!!.groupValues[1])
                    "Got it. I’ll remember that. 💜"
                }
                flag("f_remind") && remindRe.containsMatchIn(q) -> remind(q)
                urlRe.containsMatchIn(q) && flag("f_links") -> readPage(q)   // a link in your message: Neko reads the page
                flag("f_friend") -> ai.ask(q, null, history = turns.toList(), friend = true).also { remember(q, it); exchanges++ }
                else -> ai.ask(q, screenText())
            }
        }
        if (learn && flag("f_memory") && flag("m_auto") && exchanges > 0 && exchanges % 4 == 0) learnFacts()
    }

    suspend fun onChip(c: String) {
        starters[c]?.let { send(it); return }
        msgs.add(Msg(true, c))
        when {
            c.startsWith("🔎") -> { mode = "search"; msgs.add(Msg(false, "What should I search for?")) }
            c.startsWith("🌐") -> {
                mode = "task"
                msgs.add(Msg(false, "Tell me the website and what to do, like: example.com find the cheapest plan"))
            }
            c.startsWith("⏰") -> {
                mode = "remind"
                msgs.add(Msg(false, "What should I remind you about, and when? For example: in 10 minutes drink water, or tomorrow at 8 am call mom."))
            }
            c.startsWith("💬") -> reply(3) { smartReply() }
            c.startsWith("🔤") -> reply(3) { translate() }
            c.startsWith("Apply") -> reply(3) {
                val ok = pending?.let(apply) == true
                if (ok) { pending = null; "Done! I replaced your text. ✅" } else "I couldn’t edit that field. Copy the text above instead."
            }
            c.startsWith("📸") -> reply(3) {
                val shot = capture()
                ai.ask("Explain what is on my screen and what I can do here.", null, shot)
            }
            c.startsWith("Explain") -> reply(3) {
                if (!flag("p_screen")) return@reply "Screen sharing is off. You can turn it on in Privacy."
                ai.ask("Explain what is on my screen and what I can do here.", screenText())
            }
            else -> reply(3) {
                val d = draft()
                if (d.isNullOrBlank()) return@reply "I can’t see your draft. Tap into the text box, then tap my bubble and try again."
                val style = when {
                    c.contains("profess", true) -> "more professional"
                    c.contains("short", true) -> "shorter"
                    else -> "friendlier, with fitting emojis"
                }
                ai.ask("Rewrite this text to be $style. Return only the rewritten text.\n\n$d", null, plain = true).also { pending = it }
            }
        }
    }

    private fun thumb(b: Bitmap): Bitmap {
        val w = 360; val h = (b.height * (w.toFloat() / b.width)).toInt().coerceAtLeast(1)
        return Bitmap.createScaledBitmap(b, w, h, true)
    }

    // ---------- Smart reply ----------
    private fun cleanJson(raw: String) = raw.replace("```json", "").replace("```", "").trim()

    private suspend fun smartReply(): String {
        if (!flag("p_screen")) return "Screen sharing is off. You can turn it on in Privacy."
        val t = screenText()
        if (t.isNullOrBlank()) return "I can’t see a message here. Open the chat, then tap my bubble again."
        val d = draft()
        val raw = ai.ask(
            "Below is text from the user's phone screen, probably a chat. Find the latest message sent TO the user and write 3 replies " +
                "the user could send: 1) short and casual, 2) polite and complete, 3) funny and playful. Write in first person as the user, " +
                "in the same language and style as the conversation (Hinglish stays Hinglish). " +
                (if (d.isNullOrBlank()) "" else "The user already started typing: \"$d\". Keep that intent. ") +
                "Return ONLY a JSON array of exactly 3 strings.\n\nScreen text:\n$t", null, bare = true
        )
        val list = try {
            val a = JSONArray(cleanJson(raw)); (0 until minOf(3, a.length())).map { a.getString(it) }
        } catch (e: Exception) { cleanJson(raw).lines().map { it.trim().trimStart('-', '*', ' ', '1', '2', '3', '.', ')') }.filter { it.length > 1 }.take(3) }
        if (list.isEmpty()) throw NekoException("I couldn’t come up with replies for that. Try again.")
        options = list.mapIndexed { i, s -> ReplyOption(listOf("Short", "Polite", "Funny")[i.coerceAtMost(2)], s) }
        return "Here are 3 ideas. Tap one and I’ll put it in your text box. 👇"
    }

    // ---------- Translate screen ----------
    private suspend fun translate(): String {
        if (!flag("p_screen")) return "Screen sharing is off. You can turn it on in Privacy."
        val t = screenText()
        if (t.isNullOrBlank()) return "I can’t see any text here. Open the page, then tap my bubble again."
        val to = ai.translateTarget()
        return ai.ask(
            "Translate the following text from a phone screen into $to. Keep the meaning and tone, skip menus and buttons. " +
                "Return only the translation.\n\n$t", null, bare = true
        )
    }

    // ---------- Reminders ----------
    private fun whenLabel(t: LocalDateTime): String {
        val day = when (t.toLocalDate()) {
            LocalDate.now() -> "today"; LocalDate.now().plusDays(1) -> "tomorrow"
            else -> t.format(DateTimeFormatter.ofPattern("d MMM"))
        }
        return "${t.format(DateTimeFormatter.ofPattern("h:mm a"))} $day"
    }

    private fun create(at: LocalDateTime, what: String): String {
        val ms = at.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
        if (ms <= System.currentTimeMillis()) return "That time has already passed. Try a later time."
        Reminders.add(appCtx, ms, what)
        val noPerm = Build.VERSION.SDK_INT >= 33 &&
            appCtx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        return "Okay! I’ll remind you at ${whenLabel(at)}: $what ⏰" +
            if (noPerm) "\n\nAllow notifications for Neko in your phone settings so I can ping you." else ""
    }

    private suspend fun remind(q: String): String {
        val now = LocalDateTime.now()
        quickRe.find(q)?.let { m ->   // "in 10 minutes ..." needs no AI at all
            val n = m.groupValues[1].toLong(); val unit = m.groupValues[2].lowercase()
            val at = if (unit.startsWith("h")) now.plusHours(n) else now.plusMinutes(n)
            val what = m.groupValues[3].trim().ifEmpty {
                q.replace(m.value, "").replace(Regex("(?i)remind me( to)?"), "").trim()
            }.ifEmpty { "Reminder" }
            return create(at, what)
        }
        val raw = ai.ask(
            "Current local time: ${now.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm"))} (${ZoneId.systemDefault().id}). " +
                "Extract the reminder from the user's message. Return ONLY JSON like {\"when\":\"2026-11-18T17:30\",\"text\":\"call mom\"}, " +
                "where when is a local date-time in ISO format without a timezone. If there is no clear time return {\"error\":\"no time\"}. " +
                "Message: $q", null, bare = true
        )
        return try {
            val o = JSONObject(cleanJson(raw))
            if (o.has("error")) "I couldn’t find a time in that. Try: in 10 minutes drink water."
            else create(LocalDateTime.parse(o.getString("when")), o.optString("text", "Reminder"))
        } catch (e: Exception) { "I couldn’t understand the time. Try: in 10 minutes drink water." }
    }

    // ---------- Remember me (auto-learn) ----------
    private suspend fun learnFacts() {
        try {
            val convo = turns.takeLast(8).joinToString("\n") { (if (it.first) "User: " else "Neko: ") + it.second }
            val known = ai.memories().joinToString("; ")
            val raw = ai.ask(
                "From this conversation, find lasting personal facts about the USER that a friend would remember " +
                    "(name, nickname, likes, dislikes, hobbies, job or study, goals, pets, favourite things). " +
                    "Skip anything sensitive: health, money, passwords, ID numbers, exact address, or private details about other people. " +
                    "Already known: ${known.ifEmpty { "nothing" }}. Return ONLY a JSON array of up to 3 NEW short strings, or [].\n\n$convo",
                null, bare = true
            )
            val a = JSONArray(cleanJson(raw))
            for (i in 0 until minOf(3, a.length())) ai.addMemory(a.getString(i))
        } catch (e: Exception) { /* learning is best-effort */ }
    }

    // ---------- TinyFish: web ----------
    private suspend fun search(q: String): String {
        val k = ai.tfKey().ifBlank { return needKey }
        val res = TinyFishClient.search(k, q)
        if (res.isBlank()) return "I found no results for that."
        return ai.ask("Web results:\n$res\n\nUsing only these results, answer: $q\nName the top 2 sources.", null)
    }

    private suspend fun readPage(text: String): String {
        val k = ai.tfKey().ifBlank { return needKey }
        val url = urlRe.find(text)!!.value
        return ai.ask("Page content:\n${TinyFishClient.fetch(k, url)}\n\nThe user asked: $text", null)
    }

    private suspend fun task(text: String): String {
        val k = ai.tfKey().ifBlank { return needKey }
        val parts = text.trim().split(" ", limit = 2)
        val url = parts[0].let { if (it.startsWith("http")) it else "https://$it" }
        val goal = parts.getOrElse(1) { "Summarize this page" }
        val raw = TinyFishClient.agent(k, url, goal)
        return ai.ask("A web agent just did this task: $goal\nRaw result:\n$raw\n\nExplain the result briefly.", null)
    }

    /** Turn network exceptions into a sentence a person can act on. */
    private fun friendly(e: Exception): String = when (e) {
        is java.net.SocketTimeoutException -> "The AI took too long to answer. Try again, or pick a faster model (like a Flash-Lite one) in AI brain."
        is java.net.UnknownHostException -> "No internet connection. Check your data or Wi-Fi."
        is java.io.IOException -> "Network problem. Check your connection and try again."
        else -> e.message?.takeIf { it.isNotBlank() } ?: "Something went wrong."
    }

    private fun greeting(mood: Int) = when (mood) {
        1 -> "Hi… *yawn* how can I help? 😴"
        2 -> "Hi!! What are we doing today? ✨"
        3 -> "Hi. What are we figuring out? 🤔"
        else -> "Hi! How can I help you?"
    }

    /** Runs [block], shows its text as Neko's answer, saves the chat. Returns true if it succeeded. */
    private suspend fun reply(xp: Int = 2, block: suspend () -> String): Boolean {
        typing = true
        var ok = true
        val r = try { block() } catch (e: Exception) { ok = false; friendly(e) }
        typing = false
        msgs.add(Msg(false, r))
        if (ok) {
            lastReply = r; replyId++
            val g = Growth.award(ai.prefs, xp)
            if (g.leveledUp) msgs.add(Msg(false, "Level up! I’m now level ${g.level}, ${Growth.title(g.level)}. ✨" + Growth.unlockText(g.level)))
        }
        persist()
        return ok
    }

    private fun persist() {
        val s = store ?: return
        if (!flag("f_history")) return
        val first = msgs.firstOrNull { it.mine } ?: return
        s.save(SavedChat(id, first.text.take(40), System.currentTimeMillis(), s.get(id)?.pinned ?: false, msgs.map { SavedMsg(it.mine, it.text) }))
    }
}

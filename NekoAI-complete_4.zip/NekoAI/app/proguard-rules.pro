# Neko AI release rules.
# The app is small and uses a lot of Android callbacks, so keep our own code as it is;
# R8 still shrinks the libraries (Compose, icons) which is where the size is.
-keep class com.neko.ai.** { *; }
-dontwarn org.slf4j.**

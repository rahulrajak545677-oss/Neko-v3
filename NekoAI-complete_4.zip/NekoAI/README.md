# Neko AI

A floating cat assistant for Android: tap the cat bubble over any app, and Neko reads the screen, fixes your writing, looks at screenshots, listens to your voice and answers questions.
Uses the **free Google Gemini API** for answers and (optionally) **TinyFish** for web search, page reading and web tasks.

## Run it
1. Install Android Studio (Ladybug or newer). Open this folder (`NekoAI`) and let Gradle sync (it creates the Gradle wrapper for you).
2. Run on a phone with Android 8.0+ (Android 11+ for screenshots). A real device is best; overlays are limited on emulators.
3. In the app tap **Grant all permissions** and follow the steps: Overlay, Mic, then turn on *Neko AI* in Accessibility settings.
4. Open **AI brain** and paste a free Gemini key from https://aistudio.google.com/app/apikey (optional: a TinyFish key from https://agent.tinyfish.ai/api-keys).
5. Tap the cat to wake Neko, then tap the floating cat in any app. Or try everything safely in **Try Neko**.

## Screens
- **Try Neko** – a sample draft and the real chat window, inside the app.
- **Bubble look** – size, start corner, fade when idle, and **Cat style** (mood, personality, neon skin).
- **AI brain** – tone, language, reply length, keys, model.
- **Smart features** – 19 switches (friend chat, speak replies, smart reply, translate screen, reminders, remember me, chat history, cat reactions, cat growth, writing, apply, explain, screenshots, voice, search, links, web tasks, chips, haptics).
- **Chat history** – saved conversations: search, pin, delete, or continue one in the floating chat.
- **Remember me** – facts Neko remembers about you (add, delete, auto-learn on/off). Stored on the phone only.
- **Daily check-in** – a friendly notification at a time you pick; tap it to chat.
- **Reminders** – set from this screen or by typing "remind me in 10 minutes to drink water" in the chat.
- **App control** – show the bubble only in the apps you pick.
- **Privacy** – screen sharing, masking of emails/phones/cards, forget-on-close, erase keys.

## Friend chat and Talk mode
- **Friend chat** (on by default): normal messages get a warm, casual, daily-life style and Neko remembers the conversation until you close the chat. Starter chips like "Say good morning" or "Cheer me up" show on a fresh chat.
- **Speak replies** (Smart features): Neko reads answers aloud.
- **Talk mode** (headset button in the chat header): hands-free loop. You speak, Neko answers out loud, then listens again. Tap the headset again to stop.

## Cat growth
Neko starts as a small kitten and levels up as you chat (levels 1 to 10: Kitten, Street cat, Cool cat, Neko master, Neko legend). The cat grows to full size, and each level can unlock a look: Bow (Lv 2), Headphones (Lv 3), Shades (Lv 4), Crown (Lv 6), Halo (Lv 8). XP: +2 per reply, +3 for skills, +5 for the first chat each day, up to 80 a day. Open **Cat growth** to see progress, your streak, and pick a look (Auto, None, or a specific one). It can be switched off in Smart features.

## App icon
Adaptive icon with the cat on a violet-to-magenta gradient, plus a themed (monochrome) version for Android 13+. The files are `ic_launcher_bg.png`, `ic_launcher_fg.png` and `ic_launcher_mono.png` in `app/src/main/res/drawable-nodpi`.

## More chat skills
- **Smart reply** (chip): reads the latest message on screen and offers 3 replies (short, polite, funny). Tap one to put it in your text box.
- **Translate screen** (chip): translates what is on screen into the language set in AI brain.
- **Cat reactions:** the bubble breathes, squishes when tapped, wiggles with a "!" when a reminder or check-in arrives, and shows a floating "z" when idle. The chat avatar wiggles while Neko thinks.

## How the bubble behaves
Drag it anywhere; on release it snaps to the nearest corner, fades when idle, and lights up when touched.

## Notes
- Not compiled by the author: expect to fix a small error or two on first build.
- Free Gemini requests may be used by Google to improve its products. Use Privacy to stop sharing screen text.
- Keys are stored on the phone only. If you ever publish this app, move them to a backend, and review Google Play's policy for accessibility services.
- The TinyFish *Agent* endpoint (`/v1/automation/run`) was not verified; Search and Fetch match the docs.

## Release build
The workflow now makes three files each run: **NekoAI-release.apk** (signed, smaller, the one to share), **NekoAI-release.aab** (for Google Play) and **NekoAI-debug.apk**.
- **Signing key:** with no setup, the first run creates a key and remembers it (a weekly run keeps it alive), so new builds install over old ones. For a permanent key, add 4 repository secrets: `KEYSTORE_BASE64`, `KEYSTORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD`.
- **Version:** every run gets the next version number automatically.
- **Smaller app:** release uses R8 shrinking. If it ever behaves differently from debug, set `neko.minify=false` in `gradle.properties`.
- Pushing a tag like `v1.0` also attaches the files to **Releases**.

## Build the APK on GitHub
1. Create a new GitHub repository and push this folder to it (branch `main`).
2. Open the **Actions** tab, then **Build APK**. It runs on every push, or press **Run workflow**.
3. When it turns green, open the run and download **NekoAI-debug-apk** from *Artifacts*. Unzip it and install `NekoAI-debug.apk`.
4. To publish a download link: `git tag v0.2 && git push origin v0.2`. The APK appears under **Releases**.
